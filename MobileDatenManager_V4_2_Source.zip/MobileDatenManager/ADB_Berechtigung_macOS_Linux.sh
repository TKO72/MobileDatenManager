#!/usr/bin/env bash
set -e
adb devices
adb shell pm grant de.mobilepreferred.manager android.permission.WRITE_SECURE_SETTINGS
echo "Fertig. Mobile Daten Manager auf dem Handy jetzt neu öffnen."
