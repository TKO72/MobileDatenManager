@echo off
adb devices
adb shell pm grant de.mobilepreferred.manager android.permission.WRITE_SECURE_SETTINGS
if %errorlevel% neq 0 (
  echo.
  echo FEHLER: ADB-Verbindung oder Berechtigung fehlgeschlagen.
  pause
  exit /b 1
)
echo.
echo Fertig. Mobile Daten Manager auf dem Handy jetzt neu oeffnen.
pause
