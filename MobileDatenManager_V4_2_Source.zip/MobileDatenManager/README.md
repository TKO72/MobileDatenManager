# Mobile Daten Manager V4

Samsung/Android-App für drei echte Netzwerkzustände pro App:

- **AUTO** = Mobile Daten oder WLAN
- **WLAN** = Nur WLAN
- **MOBIL** = Mobile Daten bevorzugt

## Neu in V4

Der auf dem Samsung S25 Ultra verifizierte Samsung-Mechanismus ist eingebaut:

- `netpolicy` Transaktion **28**: `setFirewallRuleMobileData(uid, allow)`
- `netpolicy` Transaktion **32**: `getFirewallRuleMobileData(uid)`
- `allow = false` sperrt mobile Daten und ergibt **Nur WLAN**
- `allow = true` erlaubt mobile Daten wieder
- `mobile_data_preferred_uids` steuert zusätzlich **Mobile Daten bevorzugt**

Die App kombiniert beide Mechanismen sauber zu drei Zuständen:

| Zustand | Mobile Firewall | mobile_data_preferred_uids |
|---|---|---|
| AUTO | erlaubt | UID nicht enthalten |
| WLAN | gesperrt | UID nicht enthalten |
| MOBIL | erlaubt | UID enthalten |

## Bedienung

- App-Zeile oder Zustandsknopf antippen → AUTO / WLAN / MOBIL auswählen.
- ★ = Favorit.
- ⚠ = wichtige/geschützte App. Lange auf eine App drücken schaltet den Schutz ebenfalls um.
- Einige Kernsystem-Pakete sind automatisch geschützt.
- Sammeländerungen wirken nur auf die aktuell sichtbare Liste und lassen geschützte UIDs aus.
- System-Apps sind standardmäßig ausgeblendet.

## CSV-Profile

Profile sind normale UTF-8-CSV-Dateien mit Semikolon als Trennzeichen.

Format V2:

```csv
type;package;app;state;favorite;protected
DEFAULT;;;AUTO;;
APP;com.whatsapp;WhatsApp;WIFI;1;0
APP;com.openai.chatgpt;ChatGPT;AUTO;1;0
```

Zustände:

- `AUTO` = Mobile Daten oder WLAN
- `WIFI` = Nur WLAN
- `MOBILE` = Mobile Daten bevorzugt

`favorite`: `1` Favorit, `0` kein Favorit.

`protected`: `1` geschützt/wichtig, `0` nicht geschützt.

Beim Laden:

- vorhandene Apps übernehmen den in der CSV gespeicherten Zustand,
- Apps, die in der CSV fehlen, erhalten den im Profil gespeicherten Standard,
- bereits geschützte neue Apps werden nicht automatisch per Standard verändert,
- alte V1-Profile mit `AUTO` / `MOBILE` und ohne `protected` werden weiter gelesen.

## Shizuku / Berechtigung

V4 führt die Samsung-Firewall-Aufrufe selbst aus. **aShell und manuell eingegebene `service call`-Befehle sind nicht mehr nötig.**

Für den privilegierten Samsung-`NetworkPolicy`-Aufruf muss Shizuku jedoch aktiv sein. Das ist eine Android/Samsung-Berechtigungsgrenze: Eine normal installierte, nicht als System-App signierte APK darf diese interne Firewall-Funktion nicht direkt aufrufen.

`WRITE_SECURE_SETTINGS` wird – wie schon in V3 – einmal über den Shizuku-UserService erteilt und bleibt anschließend erhalten. Der echte WLAN-only-Firewall-Aufruf benötigt Shizuku während des Lesens/Änderns.

## Gemeinsame UID

Wenn mehrere Apps dieselbe Android-UID teilen, gilt die Netzwerkregel technisch für die gesamte UID. V4 stellt diese Apps daher gemeinsam um. Bei widersprüchlichen Profilwerten wird für die gemeinsame UID auf **AUTO** zurückgefallen.
