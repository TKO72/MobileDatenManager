package de.mobilepreferred.manager;

interface IPrivilegedService {
    int runCommand(String command);
    String runCommandWithOutput(String command);
}
