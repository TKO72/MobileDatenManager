package de.mobilepreferred.manager;

import android.content.Context;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class PrivilegedService extends IPrivilegedService.Stub {
    public PrivilegedService() {}

    public PrivilegedService(Context context) {}

    @Override
    public int runCommand(String command) {
        try {
            Process process = new ProcessBuilder("sh", "-c", command)
                    .redirectErrorStream(true)
                    .start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                while (reader.readLine() != null) {
                    // Drain output so the process cannot block.
                }
            }
            return process.waitFor();
        } catch (Exception e) {
            return -1;
        }
    }

    @Override
    public String runCommandWithOutput(String command) {
        StringBuilder out = new StringBuilder();
        try {
            Process process = new ProcessBuilder("sh", "-c", command)
                    .redirectErrorStream(true)
                    .start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (out.length() > 0) out.append('\n');
                    out.append(line);
                }
            }
            int code = process.waitFor();
            if (code != 0) {
                if (out.length() > 0) out.append('\n');
                out.append("__EXIT__=").append(code);
            }
        } catch (Exception e) {
            if (out.length() > 0) out.append('\n');
            out.append("__ERROR__=").append(e.getClass().getSimpleName());
        }
        return out.toString();
    }
}
