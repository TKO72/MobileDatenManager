package de.mobilepreferred.manager;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final String KEY_MOBILE_PREFERRED = "mobile_data_preferred_uids";
    private static final String WRITE_SECURE = "android.permission.WRITE_SECURE_SETTINGS";
    private static final int SHIZUKU_REQUEST_CODE = 1001;
    private static final int REQUEST_SAVE_PROFILE = 2001;
    private static final int REQUEST_LOAD_PROFILE = 2002;

    private static final String PREFS = "mdm_prefs";
    private static final String PREF_FAVORITES = "favorites";
    private static final String PREF_PROTECTED = "protected_packages";

    private static final int FILTER_ALL = 0;
    private static final int FILTER_WIFI = 1;
    private static final int FILTER_AUTO = 2;
    private static final int FILTER_MOBILE = 3;
    private static final int FILTER_FAVORITES = 4;
    private static final int FILTER_PROTECTED = 5;

    private final ArrayList<AppEntry> allApps = new ArrayList<>();
    private final ArrayList<Row> visibleRows = new ArrayList<>();
    private final Set<Integer> preferredUids = new HashSet<>();
    private final Set<Integer> wifiOnlyUids = new HashSet<>();
    private final Set<Integer> firewallKnownUids = new HashSet<>();
    private final Map<Integer, List<AppEntry>> appsByUid = new HashMap<>();
    private final Set<String> favorites = new HashSet<>();
    private final Set<String> protectedPackages = new HashSet<>();

    private EditText search;
    private Button filterAll;
    private Button filterFavorites;
    private Button filterProtected;
    private Button filterAuto;
    private Button filterWifi;
    private Button filterMobile;
    private TextView status;
    private TextView count;
    private CheckBox showSystem;
    private ListView list;
    private AppAdapter adapter;

    private int filter = FILTER_ALL;
    private boolean observerRegistered = false;
    private boolean bindingUserService = false;
    private boolean firewallLoading = false;

    private IPrivilegedService privilegedService;
    private Shizuku.UserServiceArgs userServiceArgs;

    private NetworkMode pendingProfileDefault = NetworkMode.AUTO;
    private Integer pendingSetUid;
    private NetworkMode pendingSetMode;

    private final Shizuku.OnBinderReceivedListener binderReceivedListener = () -> {
        runOnUiThread(() -> {
            updatePermissionStatus();
            connectPrivilegedService(false);
        });
    };

    private final Shizuku.OnBinderDeadListener binderDeadListener = () -> runOnUiThread(() -> {
        privilegedService = null;
        bindingUserService = false;
        firewallKnownUids.clear();
        wifiOnlyUids.clear();
        updatePermissionStatus();
        refreshRows();
    });

    private final Shizuku.OnRequestPermissionResultListener permissionResultListener = (requestCode, grantResult) -> {
        if (requestCode != SHIZUKU_REQUEST_CODE) return;
        if (grantResult == PackageManager.PERMISSION_GRANTED) {
            connectPrivilegedService(true);
        } else {
            Toast.makeText(this, "Shizuku-Berechtigung wurde nicht erteilt.", Toast.LENGTH_LONG).show();
            updatePermissionStatus();
        }
    };

    private final ServiceConnection userServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            bindingUserService = false;
            privilegedService = IPrivilegedService.Stub.asInterface(service);
            updatePermissionStatus();
            if (!hasWritePermission()) {
                runGrantCommand();
            } else {
                processPendingNetworkAction();
                loadFirewallStatesAsync();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            privilegedService = null;
            bindingUserService = false;
            firewallKnownUids.clear();
            wifiOnlyUids.clear();
            updatePermissionStatus();
            refreshRows();
        }
    };

    private final ContentObserver settingsObserver = new ContentObserver(new Handler(Looper.getMainLooper())) {
        @Override
        public void onChange(boolean selfChange) {
            readPreferredUids();
            refreshRows();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener);
        Shizuku.addBinderDeadListener(binderDeadListener);
        Shizuku.addRequestPermissionResultListener(permissionResultListener);
        loadFavorites();
        loadProtectedPackages();
        buildUi();
        loadApps();
        readPreferredUids();
        refreshRows();
        registerSettingObserver();
        connectPrivilegedService(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        readPreferredUids();
        updatePermissionStatus();
        connectPrivilegedService(false);
        if (privilegedService != null) loadFirewallStatesAsync();
        refreshRows();
    }

    @Override
    protected void onDestroy() {
        if (observerRegistered) getContentResolver().unregisterContentObserver(settingsObserver);
        Shizuku.removeBinderReceivedListener(binderReceivedListener);
        Shizuku.removeBinderDeadListener(binderDeadListener);
        Shizuku.removeRequestPermissionResultListener(permissionResultListener);
        try {
            if (userServiceArgs != null && privilegedService != null) {
                Shizuku.unbindUserService(userServiceArgs, userServiceConnection, true);
            }
        } catch (Throwable ignored) {}
        super.onDestroy();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(12);
        root.setPadding(p, p, p, dp(6));

        TextView title = new TextView(this);
        title.setText("Mobile Daten Manager");
        title.setTextSize(24);
        title.setTypeface(null, 1);
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView hint = new TextView(this);
        hint.setText("AUTO = Mobile Daten oder WLAN · WLAN = Nur WLAN · MOBIL = Mobile Daten bevorzugt");
        hint.setTextSize(12);
        hint.setPadding(0, dp(4), 0, dp(7));
        root.addView(hint);

        status = new TextView(this);
        status.setTextSize(13);
        status.setPadding(dp(10), dp(8), dp(10), dp(8));
        status.setOnClickListener(v -> showPermissionHelp());
        root.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        search = new EditText(this);
        search.setHint("Apps suchen …");
        search.setSingleLine(true);
        search.setTextSize(17);
        root.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        LinearLayout filterTop = new LinearLayout(this);
        filterTop.setOrientation(LinearLayout.HORIZONTAL);
        filterTop.setPadding(0, dp(6), 0, dp(2));
        filterAll = makeButton("Alle");
        filterFavorites = makeButton("★");
        filterProtected = makeButton("⚠");
        filterTop.addView(filterAll, weightParams());
        filterTop.addView(filterFavorites, weightParams());
        filterTop.addView(filterProtected, weightParams());
        root.addView(filterTop);

        LinearLayout filterModes = new LinearLayout(this);
        filterModes.setOrientation(LinearLayout.HORIZONTAL);
        filterAuto = makeButton("AUTO");
        filterWifi = makeButton("WLAN");
        filterMobile = makeButton("MOBIL");
        filterModes.addView(filterAuto, weightParams());
        filterModes.addView(filterWifi, weightParams());
        filterModes.addView(filterMobile, weightParams());
        root.addView(filterModes);

        LinearLayout bulk = new LinearLayout(this);
        bulk.setOrientation(LinearLayout.HORIZONTAL);
        bulk.setPadding(0, dp(4), 0, 0);
        Button allAuto = makeButton("Alle AUTO");
        Button allWifi = makeButton("Alle WLAN");
        Button allMobile = makeButton("Alle MOBIL");
        bulk.addView(allAuto, weightParams());
        bulk.addView(allWifi, weightParams());
        bulk.addView(allMobile, weightParams());
        root.addView(bulk);

        LinearLayout profiles = new LinearLayout(this);
        profiles.setOrientation(LinearLayout.HORIZONTAL);
        profiles.setPadding(0, dp(4), 0, dp(2));
        Button saveProfile = makeButton("Profil speichern");
        Button loadProfile = makeButton("Profil laden");
        profiles.addView(saveProfile, weightParams());
        profiles.addView(loadProfile, weightParams());
        root.addView(profiles);

        LinearLayout options = new LinearLayout(this);
        options.setOrientation(LinearLayout.HORIZONTAL);
        options.setGravity(Gravity.CENTER_VERTICAL);
        showSystem = new CheckBox(this);
        showSystem.setText("System-Apps anzeigen");
        options.addView(showSystem, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        count = new TextView(this);
        count.setTextSize(11);
        count.setGravity(Gravity.END);
        options.addView(count, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(options);

        list = new ListView(this);
        list.setDividerHeight(1);
        adapter = new AppAdapter(this);
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { refreshRows(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        filterAll.setOnClickListener(v -> { filter = FILTER_ALL; refreshRows(); });
        filterWifi.setOnClickListener(v -> { filter = FILTER_WIFI; refreshRows(); });
        filterAuto.setOnClickListener(v -> { filter = FILTER_AUTO; refreshRows(); });
        filterMobile.setOnClickListener(v -> { filter = FILTER_MOBILE; refreshRows(); });
        filterFavorites.setOnClickListener(v -> { filter = FILTER_FAVORITES; refreshRows(); });
        filterProtected.setOnClickListener(v -> { filter = FILTER_PROTECTED; refreshRows(); });
        showSystem.setOnCheckedChangeListener((buttonView, isChecked) -> refreshRows());

        allAuto.setOnClickListener(v -> confirmBulk(NetworkMode.AUTO));
        allWifi.setOnClickListener(v -> confirmBulk(NetworkMode.WIFI_ONLY));
        allMobile.setOnClickListener(v -> confirmBulk(NetworkMode.MOBILE_PREFERRED));
        saveProfile.setOnClickListener(v -> chooseProfileDefaultAndSave());
        loadProfile.setOnClickListener(v -> openProfile());

        updatePermissionStatus();
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setMinHeight(dp(44));
        return b;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> installed = pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(PackageManager.MATCH_ALL));
        Collator collator = Collator.getInstance(Locale.GERMAN);
        collator.setStrength(Collator.PRIMARY);

        allApps.clear();
        appsByUid.clear();

        for (ApplicationInfo ai : installed) {
            if (getPackageName().equals(ai.packageName)) continue;
            if (pm.checkPermission(Manifest.permission.INTERNET, ai.packageName) != PackageManager.PERMISSION_GRANTED) continue;

            String label;
            try { label = pm.getApplicationLabel(ai).toString(); }
            catch (Exception e) { label = ai.packageName; }

            boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                    || (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
            Drawable icon;
            try { icon = pm.getApplicationIcon(ai); }
            catch (Exception e) { icon = getApplicationInfo().loadIcon(pm); }

            AppEntry app = new AppEntry(label, ai.packageName, ai.uid, system, icon);
            allApps.add(app);
            appsByUid.computeIfAbsent(ai.uid, k -> new ArrayList<>()).add(app);
        }

        Collections.sort(allApps, (a, b) -> collator.compare(a.label, b.label));
    }

    private void loadFavorites() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Set<String> saved = prefs.getStringSet(PREF_FAVORITES, Collections.emptySet());
        favorites.clear();
        if (saved != null) favorites.addAll(saved);
    }

    private void persistFavorites() {
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putStringSet(PREF_FAVORITES, new HashSet<>(favorites))
                .apply();
    }

    private void toggleFavorite(String packageName) {
        if (favorites.contains(packageName)) favorites.remove(packageName);
        else favorites.add(packageName);
        persistFavorites();
        refreshRows();
    }

    private void loadProtectedPackages() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Set<String> saved = prefs.getStringSet(PREF_PROTECTED, Collections.emptySet());
        protectedPackages.clear();
        if (saved != null) protectedPackages.addAll(saved);
    }

    private void persistProtectedPackages() {
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putStringSet(PREF_PROTECTED, new HashSet<>(protectedPackages))
                .apply();
    }

    private void toggleProtected(AppEntry app) {
        if (isBuiltInCritical(app.packageName)) {
            Toast.makeText(this, "Diese Kernsystem-App ist automatisch geschützt.", Toast.LENGTH_LONG).show();
            return;
        }
        if (protectedPackages.contains(app.packageName)) protectedPackages.remove(app.packageName);
        else protectedPackages.add(app.packageName);
        persistProtectedPackages();
        refreshRows();
    }

    private boolean isBuiltInCritical(String packageName) {
        return "android".equals(packageName)
                || "com.android.systemui".equals(packageName)
                || "com.android.phone".equals(packageName)
                || "com.android.providers.settings".equals(packageName)
                || "com.android.providers.downloads".equals(packageName)
                || "com.google.android.gms".equals(packageName)
                || "com.google.android.gsf".equals(packageName);
    }

    private boolean isProtected(AppEntry app) {
        return isBuiltInCritical(app.packageName) || protectedPackages.contains(app.packageName);
    }

    private boolean isUidProtected(int uid) {
        List<AppEntry> shared = appsByUid.get(uid);
        if (shared == null) return false;
        for (AppEntry app : shared) if (isProtected(app)) return true;
        return false;
    }

    private void readPreferredUids() {
        preferredUids.clear();
        String raw = Settings.Secure.getString(getContentResolver(), KEY_MOBILE_PREFERRED);
        if (raw == null || raw.trim().isEmpty()) return;
        for (String s : raw.split(";")) {
            try { preferredUids.add(Integer.parseInt(s.trim())); }
            catch (NumberFormatException ignored) {}
        }
    }

    private boolean writePreferredUids(Set<Integer> newSet) {
        if (!hasWritePermission()) {
            showPermissionHelp();
            return false;
        }
        ArrayList<Integer> sorted = new ArrayList<>(newSet);
        Collections.sort(sorted);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sorted.size(); i++) {
            if (i > 0) sb.append(';');
            sb.append(sorted.get(i));
        }
        try {
            boolean ok = Settings.Secure.putString(getContentResolver(), KEY_MOBILE_PREFERRED, sb.toString());
            if (!ok) {
                Toast.makeText(this, "Android hat die Einstellung nicht übernommen.", Toast.LENGTH_LONG).show();
                return false;
            }
            readPreferredUids();
            return true;
        } catch (SecurityException e) {
            updatePermissionStatus();
            showPermissionHelp();
            return false;
        }
    }

    private NetworkMode modeForUid(int uid) {
        if (firewallKnownUids.contains(uid) && wifiOnlyUids.contains(uid)) return NetworkMode.WIFI_ONLY;
        if (preferredUids.contains(uid)) return NetworkMode.MOBILE_PREFERRED;
        if (firewallKnownUids.contains(uid)) return NetworkMode.AUTO;
        return NetworkMode.UNKNOWN;
    }

    private void refreshRows() {
        if (adapter == null) return;
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        boolean system = showSystem != null && showSystem.isChecked();

        ArrayList<AppEntry> wifi = new ArrayList<>();
        ArrayList<AppEntry> auto = new ArrayList<>();
        ArrayList<AppEntry> mobile = new ArrayList<>();
        ArrayList<AppEntry> unknown = new ArrayList<>();

        int favoriteCount = 0;
        int protectedCount = 0;
        int candidateCount = 0;

        for (AppEntry app : allApps) {
            if (!system && app.system) continue;
            if (!q.isEmpty()) {
                String hay = (app.label + " " + app.packageName).toLowerCase(Locale.ROOT);
                if (!hay.contains(q)) continue;
            }

            NetworkMode mode = modeForUid(app.uid);
            boolean favorite = favorites.contains(app.packageName);
            boolean protectedApp = isProtected(app);
            favoriteCount += favorite ? 1 : 0;
            protectedCount += protectedApp ? 1 : 0;
            candidateCount++;

            if (filter == FILTER_WIFI && mode != NetworkMode.WIFI_ONLY) continue;
            if (filter == FILTER_AUTO && mode != NetworkMode.AUTO) continue;
            if (filter == FILTER_MOBILE && mode != NetworkMode.MOBILE_PREFERRED) continue;
            if (filter == FILTER_FAVORITES && !favorite) continue;
            if (filter == FILTER_PROTECTED && !protectedApp) continue;

            switch (mode) {
                case WIFI_ONLY: wifi.add(app); break;
                case MOBILE_PREFERRED: mobile.add(app); break;
                case AUTO: auto.add(app); break;
                default: unknown.add(app); break;
            }
        }

        visibleRows.clear();
        addSection("NUR WLAN", wifi);
        addSection("MOBILE DATEN BEVORZUGT", mobile);
        addSection("AUTO: MOBILE DATEN ODER WLAN", auto);
        addSection("STATUS NOCH NICHT GELESEN", unknown);

        count.setText("A " + auto.size() + " · W " + wifi.size() + " · M " + mobile.size() + (unknown.isEmpty() ? "" : " · ? " + unknown.size()));
        filterAll.setText("Alle\n" + candidateCount);
        filterFavorites.setText("★\n" + favoriteCount);
        filterProtected.setText("⚠\n" + protectedCount);
        filterAuto.setText("AUTO\n" + countModeInScope(NetworkMode.AUTO, q, system));
        filterWifi.setText("WLAN\n" + countModeInScope(NetworkMode.WIFI_ONLY, q, system));
        filterMobile.setText("MOBIL\n" + countModeInScope(NetworkMode.MOBILE_PREFERRED, q, system));
        adapter.notifyDataSetChanged();
    }

    private int countModeInScope(NetworkMode wanted, String q, boolean system) {
        int n = 0;
        for (AppEntry app : allApps) {
            if (!system && app.system) continue;
            if (!q.isEmpty()) {
                String hay = (app.label + " " + app.packageName).toLowerCase(Locale.ROOT);
                if (!hay.contains(q)) continue;
            }
            if (modeForUid(app.uid) == wanted) n++;
        }
        return n;
    }

    private void addSection(String title, List<AppEntry> apps) {
        if (apps.isEmpty()) return;
        visibleRows.add(Row.header(title, apps.size()));
        for (AppEntry app : apps) visibleRows.add(Row.app(app));
    }

    private void showModeDialog(AppEntry app) {
        NetworkMode current = modeForUid(app.uid);
        String[] choices = {
                "AUTO – Mobile Daten oder WLAN",
                "WLAN – Nur WLAN",
                "MOBIL – Mobile Daten bevorzugt"
        };
        int checked = current == NetworkMode.WIFI_ONLY ? 1 : current == NetworkMode.MOBILE_PREFERRED ? 2 : 0;

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(app.label)
                .setSingleChoiceItems(choices, checked, null)
                .setNegativeButton("Abbrechen", null)
                .create();
        dialog.setOnShowListener(x -> dialog.getListView().setOnItemClickListener((parent, view, position, id) -> {
            NetworkMode wanted = position == 1 ? NetworkMode.WIFI_ONLY
                    : position == 2 ? NetworkMode.MOBILE_PREFERRED : NetworkMode.AUTO;
            dialog.dismiss();
            requestSetNetworkMode(app, wanted);
        }));
        dialog.show();
    }

    private void requestSetNetworkMode(AppEntry app, NetworkMode wanted) {
        NetworkMode current = modeForUid(app.uid);
        if (current == wanted) return;

        if (isProtected(app) && wanted == NetworkMode.WIFI_ONLY) {
            new AlertDialog.Builder(this)
                    .setTitle("Geschützte App")
                    .setMessage("„" + app.label + "“ ist als wichtig/geschützt markiert. Nur WLAN kann Benachrichtigungen oder andere Funktionen beeinflussen. Trotzdem umstellen?")
                    .setNegativeButton("Abbrechen", null)
                    .setPositiveButton("Trotzdem", (d, w) -> queueOrApplyNetworkMode(app.uid, wanted))
                    .show();
        } else {
            queueOrApplyNetworkMode(app.uid, wanted);
        }
    }

    private void queueOrApplyNetworkMode(int uid, NetworkMode wanted) {
        if (!hasWritePermission() || privilegedService == null) {
            pendingSetUid = uid;
            pendingSetMode = wanted;
            showPermissionHelp();
            return;
        }
        applyNetworkModeToUids(Collections.singleton(uid), wanted, false);
    }

    private void processPendingNetworkAction() {
        if (pendingSetUid == null || pendingSetMode == null) return;
        if (!hasWritePermission() || privilegedService == null) return;
        int uid = pendingSetUid;
        NetworkMode mode = pendingSetMode;
        pendingSetUid = null;
        pendingSetMode = null;
        applyNetworkModeToUids(Collections.singleton(uid), mode, false);
    }

    private void confirmBulk(NetworkMode mode) {
        LinkedHashSet<Integer> targets = new LinkedHashSet<>();
        int protectedSkipped = 0;
        Set<Integer> protectedSeen = new HashSet<>();
        for (Row row : visibleRows) {
            if (row.header || row.app == null) continue;
            int uid = row.app.uid;
            if (isUidProtected(uid)) {
                if (protectedSeen.add(uid)) protectedSkipped++;
                continue;
            }
            targets.add(uid);
        }

        if (targets.isEmpty()) {
            Toast.makeText(this, protectedSkipped > 0 ? "Nur geschützte Apps sichtbar – nichts geändert." : "Keine Apps sichtbar.", Toast.LENGTH_LONG).show();
            return;
        }

        String msg = targets.size() + " UID(s) der aktuell sichtbaren Liste auf „" + mode.shortLabel + "“ setzen.";
        if (protectedSkipped > 0) msg += "\n\n" + protectedSkipped + " geschützte UID(s) werden ausgelassen.";

        new AlertDialog.Builder(this)
                .setTitle("Sammeländerung")
                .setMessage(msg)
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton(mode.shortLabel, (d, w) -> {
                    if (!hasWritePermission() || privilegedService == null) {
                        showPermissionHelp();
                        return;
                    }
                    applyNetworkModeToUids(targets, mode, true);
                })
                .show();
    }

    private void applyNetworkModeToUids(Set<Integer> targetUids, NetworkMode mode, boolean bulk) {
        if (mode == NetworkMode.UNKNOWN || targetUids.isEmpty()) return;
        if (privilegedService == null || !hasWritePermission()) {
            showPermissionHelp();
            return;
        }

        final Set<Integer> targets = new LinkedHashSet<>(targetUids);
        final boolean expectWifiBlocked = mode == NetworkMode.WIFI_ONLY;
        final IPrivilegedService service = privilegedService;

        status.setText("Samsung-Netzwerkregel wird gesetzt …");
        status.setTextColor(Color.rgb(120, 90, 0));

        new Thread(() -> {
            String output = "";
            try {
                String command = buildFirewallSetAndVerifyCommand(targets, expectWifiBlocked);
                output = service.runCommandWithOutput(command);
            } catch (RemoteException ignored) {}

            Map<Integer, Boolean> verifiedMap = parseFirewallOutput(output);
            Set<Integer> verified = new HashSet<>();
            for (Integer uid : targets) {
                Boolean blocked = verifiedMap.get(uid);
                if (blocked != null && blocked == expectWifiBlocked) verified.add(uid);
            }

            runOnUiThread(() -> {
                if (!verified.isEmpty()) {
                    firewallKnownUids.addAll(verified);
                    if (expectWifiBlocked) wifiOnlyUids.addAll(verified);
                    else wifiOnlyUids.removeAll(verified);

                    Set<Integer> next = new HashSet<>(preferredUids);
                    if (mode == NetworkMode.MOBILE_PREFERRED) next.addAll(verified);
                    else next.removeAll(verified);
                    writePreferredUids(next);
                    refreshRows();
                }

                updatePermissionStatus();
                int failed = targets.size() - verified.size();
                if (failed == 0) {
                    if (!bulk && targets.size() == 1) {
                        int uid = targets.iterator().next();
                        List<AppEntry> shared = appsByUid.get(uid);
                        String suffix = shared != null && shared.size() > 1 ? " · gemeinsame UID: alle zugehörigen Apps" : "";
                        Toast.makeText(this, mode.longLabel + suffix, Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(this, "Fertig: " + verified.size() + " UID(s) auf " + mode.shortLabel + ".", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(this, "Teilweise fehlgeschlagen: " + failed + " von " + targets.size() + " UID(s).", Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    private String buildFirewallSetAndVerifyCommand(Set<Integer> uids, boolean blockMobile) {
        StringBuilder sb = new StringBuilder("for u in");
        for (Integer uid : uids) sb.append(' ').append(uid);
        sb.append("; do ");
        sb.append("service call netpolicy 28 i32 \"$u\" i32 ").append(blockMobile ? '0' : '1').append(" >/dev/null 2>&1; ");
        sb.append("o=$(service call netpolicy 32 i32 \"$u\" 2>/dev/null); ");
        sb.append("case \"$o\" in ");
        sb.append("*\"00000000 00000001\"*) echo \"$u=1\";; ");
        sb.append("*\"00000000 00000000\"*) echo \"$u=0\";; ");
        sb.append("*) echo \"$u=?\";; esac; done");
        return sb.toString();
    }

    private String buildFirewallQueryCommand(Set<Integer> uids) {
        StringBuilder sb = new StringBuilder("for u in");
        for (Integer uid : uids) sb.append(' ').append(uid);
        sb.append("; do ");
        sb.append("o=$(service call netpolicy 32 i32 \"$u\" 2>/dev/null); ");
        sb.append("case \"$o\" in ");
        sb.append("*\"00000000 00000001\"*) echo \"$u=1\";; ");
        sb.append("*\"00000000 00000000\"*) echo \"$u=0\";; ");
        sb.append("*) echo \"$u=?\";; esac; done");
        return sb.toString();
    }

    private Map<Integer, Boolean> parseFirewallOutput(String output) {
        Map<Integer, Boolean> result = new HashMap<>();
        if (output == null || output.trim().isEmpty()) return result;
        for (String line : output.split("\\r?\\n")) {
            String s = line.trim();
            int eq = s.indexOf('=');
            if (eq <= 0) continue;
            try {
                int uid = Integer.parseInt(s.substring(0, eq).trim());
                String value = s.substring(eq + 1).trim();
                if ("1".equals(value)) result.put(uid, true);
                else if ("0".equals(value)) result.put(uid, false);
            } catch (NumberFormatException ignored) {}
        }
        return result;
    }

    private void loadFirewallStatesAsync() {
        if (privilegedService == null || firewallLoading || allApps.isEmpty()) return;
        firewallLoading = true;
        final IPrivilegedService service = privilegedService;
        LinkedHashSet<Integer> uids = new LinkedHashSet<>();
        for (AppEntry app : allApps) uids.add(app.uid);
        final Set<Integer> requested = new LinkedHashSet<>(uids);

        status.setText("Samsung-Netzwerkregeln werden gelesen …");
        status.setTextColor(Color.rgb(120, 90, 0));

        new Thread(() -> {
            String output = "";
            try { output = service.runCommandWithOutput(buildFirewallQueryCommand(requested)); }
            catch (RemoteException ignored) {}
            Map<Integer, Boolean> parsed = parseFirewallOutput(output);

            runOnUiThread(() -> {
                firewallLoading = false;
                firewallKnownUids.clear();
                wifiOnlyUids.clear();
                for (Map.Entry<Integer, Boolean> entry : parsed.entrySet()) {
                    firewallKnownUids.add(entry.getKey());
                    if (entry.getValue()) wifiOnlyUids.add(entry.getKey());
                }
                updatePermissionStatus();
                refreshRows();
                processPendingNetworkAction();
            });
        }).start();
    }

    private void chooseProfileDefaultAndSave() {
        if (hasUnknownModes()) {
            if (privilegedService != null) loadFirewallStatesAsync();
            else showPermissionHelp();
            Toast.makeText(this, "Für ein vollständiges Profil müssen zuerst alle Samsung-Netzwerkzustände gelesen werden.", Toast.LENGTH_LONG).show();
            return;
        }

        final String[] choices = {
                "AUTO – Mobile Daten oder WLAN",
                "WLAN – Nur WLAN",
                "MOBIL – Mobile Daten bevorzugt"
        };
        new AlertDialog.Builder(this)
                .setTitle("Standard für fehlende Apps")
                .setSingleChoiceItems(choices, 0, null)
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Weiter", (dialog, which) -> {
                    AlertDialog ad = (AlertDialog) dialog;
                    int checked = ad.getListView().getCheckedItemPosition();
                    pendingProfileDefault = checked == 1 ? NetworkMode.WIFI_ONLY
                            : checked == 2 ? NetworkMode.MOBILE_PREFERRED : NetworkMode.AUTO;
                    createProfile();
                })
                .show();
    }

    private boolean hasUnknownModes() {
        for (AppEntry app : allApps) if (modeForUid(app.uid) == NetworkMode.UNKNOWN) return true;
        return false;
    }

    private void createProfile() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/csv");
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.GERMANY).format(new Date());
        i.putExtra(Intent.EXTRA_TITLE, "MobileDatenProfil_" + stamp + ".csv");
        startActivityForResult(i, REQUEST_SAVE_PROFILE);
    }

    private void openProfile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        String[] mimeTypes = {"text/csv", "text/comma-separated-values", "text/plain", "application/csv"};
        i.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
        startActivityForResult(i, REQUEST_LOAD_PROFILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQUEST_SAVE_PROFILE) saveProfileToUri(uri);
        else if (requestCode == REQUEST_LOAD_PROFILE) loadProfileFromUri(uri);
    }

    private void saveProfileToUri(Uri uri) {
        if (hasUnknownModes()) {
            Toast.makeText(this, "Profil nicht gespeichert: Netzwerkstatus ist nicht vollständig bekannt.", Toast.LENGTH_LONG).show();
            return;
        }
        try (OutputStream os = getContentResolver().openOutputStream(uri, "wt");
             BufferedWriter w = new BufferedWriter(new OutputStreamWriter(os, StandardCharsets.UTF_8))) {
            w.write("# MobileDatenManager Profile v2");
            w.newLine();
            w.write("type;package;app;state;favorite;protected");
            w.newLine();
            w.write("DEFAULT;;;" + pendingProfileDefault.csvValue + ";;");
            w.newLine();
            for (AppEntry app : allApps) {
                NetworkMode mode = modeForUid(app.uid);
                String fav = favorites.contains(app.packageName) ? "1" : "0";
                String prot = isProtected(app) ? "1" : "0";
                w.write("APP;" + csv(app.packageName) + ";" + csv(app.label) + ";" + mode.csvValue + ";" + fav + ";" + prot);
                w.newLine();
            }
            w.flush();
            Toast.makeText(this, "CSV-Profil gespeichert: " + allApps.size() + " Apps", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Profil konnte nicht gespeichert werden: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void loadProfileFromUri(Uri uri) {
        try (InputStream is = getContentResolver().openInputStream(uri);
             BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            Map<String, ProfileRecord> records = new HashMap<>();
            NetworkMode defaultMode = NetworkMode.AUTO;
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                List<String> fields = parseCsvLine(line);
                if (fields.size() < 4) continue;
                if ("type".equalsIgnoreCase(fields.get(0))) continue;
                if ("DEFAULT".equalsIgnoreCase(fields.get(0))) {
                    defaultMode = NetworkMode.fromCsv(fields.get(3));
                    if (defaultMode == NetworkMode.UNKNOWN) defaultMode = NetworkMode.AUTO;
                    continue;
                }
                if (!"APP".equalsIgnoreCase(fields.get(0)) || fields.size() < 5) continue;
                String pkg = fields.get(1);
                NetworkMode mode = NetworkMode.fromCsv(fields.get(3));
                if (mode == NetworkMode.UNKNOWN) mode = NetworkMode.AUTO;
                boolean favorite = "1".equals(fields.get(4)) || "true".equalsIgnoreCase(fields.get(4));
                boolean protectedFlag = fields.size() >= 6 && ("1".equals(fields.get(5)) || "true".equalsIgnoreCase(fields.get(5)));
                records.put(pkg, new ProfileRecord(mode, favorite, protectedFlag));
            }
            showProfilePreview(records, defaultMode);
        } catch (Exception e) {
            Toast.makeText(this, "Profil konnte nicht gelesen werden: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showProfilePreview(Map<String, ProfileRecord> records, NetworkMode defaultMode) {
        int fromProfile = 0;
        int byDefault = 0;
        int favoritesInProfile = 0;
        int protectedInProfile = 0;
        int protectedDefaultSkipped = 0;
        Set<String> installed = new HashSet<>();

        for (AppEntry app : allApps) {
            installed.add(app.packageName);
            ProfileRecord pr = records.get(app.packageName);
            if (pr != null) {
                fromProfile++;
                if (pr.favorite) favoritesInProfile++;
                if (pr.protectedFlag) protectedInProfile++;
            } else {
                byDefault++;
                if (isProtected(app)) protectedDefaultSkipped++;
            }
        }
        int notInstalled = 0;
        for (String pkg : records.keySet()) if (!installed.contains(pkg)) notInstalled++;

        String msg = "Installierte Apps: " + allApps.size()
                + "\nAus Profil: " + fromProfile
                + "\nFehlend → Standard: " + byDefault
                + "\nStandard: " + defaultMode.shortLabel
                + "\nFavoriten im Profil: " + favoritesInProfile
                + "\nGeschützt im Profil: " + protectedInProfile
                + "\nGeschützte neue Apps: " + protectedDefaultSkipped + " (werden nicht per Standard geändert)"
                + "\nProfil-Apps nicht installiert: " + notInstalled;

        if (!hasWritePermission() || privilegedService == null) {
            msg += "\n\nFür das Anwenden muss Shizuku aktiv und verbunden sein.";
        }

        new AlertDialog.Builder(this)
                .setTitle("Profil prüfen")
                .setMessage(msg)
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Profil anwenden", (d, w) -> applyProfile(records, defaultMode))
                .show();
    }

    private void applyProfile(Map<String, ProfileRecord> records, NetworkMode defaultMode) {
        if (!hasWritePermission() || privilegedService == null) {
            showPermissionHelp();
            return;
        }

        Map<Integer, NetworkMode> desiredByUid = new HashMap<>();
        int conflicts = 0;
        int protectedSkipped = 0;
        Set<String> newFavorites = new HashSet<>(favorites);
        Set<String> newProtected = new HashSet<>(protectedPackages);

        for (AppEntry app : allApps) {
            ProfileRecord pr = records.get(app.packageName);
            NetworkMode desired;
            if (pr != null) {
                desired = pr.mode;
                if (pr.favorite) newFavorites.add(app.packageName); else newFavorites.remove(app.packageName);
                if (!isBuiltInCritical(app.packageName)) {
                    if (pr.protectedFlag) newProtected.add(app.packageName); else newProtected.remove(app.packageName);
                }
            } else {
                if (isProtected(app)) {
                    protectedSkipped++;
                    continue;
                }
                desired = defaultMode;
            }

            NetworkMode existing = desiredByUid.get(app.uid);
            if (existing == null) {
                desiredByUid.put(app.uid, desired);
            } else if (existing != desired) {
                desiredByUid.put(app.uid, NetworkMode.AUTO);
                conflicts++;
            }
        }

        final int conflictCount = conflicts;
        final int skippedCount = protectedSkipped;
        final Set<String> favoritesAfter = newFavorites;
        final Set<String> protectedAfter = newProtected;

        applyProfileModesSequentially(desiredByUid, () -> {
            favorites.clear();
            favorites.addAll(favoritesAfter);
            persistFavorites();
            protectedPackages.clear();
            protectedPackages.addAll(protectedAfter);
            persistProtectedPackages();
            refreshRows();
            String text = "Profil angewendet · " + favorites.size() + " Favoriten";
            if (conflictCount > 0) text += " · " + conflictCount + " UID-Konflikt(e) → AUTO";
            if (skippedCount > 0) text += " · " + skippedCount + " geschützte neue App(s) ausgelassen";
            Toast.makeText(this, text, Toast.LENGTH_LONG).show();
        });
    }

    private void applyProfileModesSequentially(Map<Integer, NetworkMode> desiredByUid, Runnable done) {
        if (desiredByUid.isEmpty()) {
            done.run();
            return;
        }
        final IPrivilegedService service = privilegedService;
        if (service == null) {
            showPermissionHelp();
            return;
        }

        status.setText("Profil wird angewendet …");
        status.setTextColor(Color.rgb(120, 90, 0));

        new Thread(() -> {
            Map<Integer, NetworkMode> verifiedModes = new HashMap<>();
            Set<Integer> blockMobile = new LinkedHashSet<>();
            Set<Integer> allowMobile = new LinkedHashSet<>();
            for (Map.Entry<Integer, NetworkMode> e : desiredByUid.entrySet()) {
                if (e.getValue() == NetworkMode.WIFI_ONLY) blockMobile.add(e.getKey());
                else allowMobile.add(e.getKey());
            }

            Map<Integer, Boolean> firewallResults = new HashMap<>();
            try {
                if (!blockMobile.isEmpty()) {
                    firewallResults.putAll(parseFirewallOutput(
                            service.runCommandWithOutput(buildFirewallSetAndVerifyCommand(blockMobile, true))));
                }
                if (!allowMobile.isEmpty()) {
                    firewallResults.putAll(parseFirewallOutput(
                            service.runCommandWithOutput(buildFirewallSetAndVerifyCommand(allowMobile, false))));
                }
            } catch (RemoteException ignored) {}

            for (Map.Entry<Integer, NetworkMode> e : desiredByUid.entrySet()) {
                Boolean got = firewallResults.get(e.getKey());
                boolean expectedBlocked = e.getValue() == NetworkMode.WIFI_ONLY;
                if (got != null && got == expectedBlocked) verifiedModes.put(e.getKey(), e.getValue());
            }

            runOnUiThread(() -> {
                Set<Integer> next = new HashSet<>(preferredUids);
                for (Map.Entry<Integer, NetworkMode> e : verifiedModes.entrySet()) {
                    int uid = e.getKey();
                    NetworkMode mode = e.getValue();
                    firewallKnownUids.add(uid);
                    if (mode == NetworkMode.WIFI_ONLY) wifiOnlyUids.add(uid); else wifiOnlyUids.remove(uid);
                    if (mode == NetworkMode.MOBILE_PREFERRED) next.add(uid); else next.remove(uid);
                }
                writePreferredUids(next);
                updatePermissionStatus();
                refreshRows();
                if (verifiedModes.size() == desiredByUid.size()) {
                    done.run();
                } else {
                    Toast.makeText(this, "Profil nur teilweise angewendet: " + verifiedModes.size() + " von " + desiredByUid.size() + " UID(s).", Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    private String csv(String value) {
        if (value == null) return "";
        String v = value.replace("\r", " ").replace("\n", " ");
        if (v.contains(";") || v.contains("\"") || v.startsWith(" ") || v.endsWith(" ")) {
            return "\"" + v.replace("\"", "\"\"") + "\"";
        }
        return v;
    }

    private List<String> parseCsvLine(String line) {
        ArrayList<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    cur.append('"');
                    i++;
                } else {
                    quoted = !quoted;
                }
            } else if (c == ';' && !quoted) {
                out.add(cur.toString());
                cur.setLength(0);
            } else {
                cur.append(c);
            }
        }
        out.add(cur.toString());
        return out;
    }

    private boolean hasWritePermission() {
        return checkSelfPermission(WRITE_SECURE) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean shizukuRunning() {
        try { return Shizuku.pingBinder(); }
        catch (Throwable ignored) { return false; }
    }

    private boolean shizukuPermissionGranted() {
        try { return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable ignored) { return false; }
    }

    private void updatePermissionStatus() {
        if (status == null) return;

        if (privilegedService != null && hasWritePermission()) {
            int known = firewallKnownUids.size();
            status.setText("✓ Shizuku aktiv – Samsung-Regeln direkt steuerbar" + (known > 0 ? " · " + known + " UID(s) gelesen" : ""));
            status.setTextColor(Color.rgb(0, 115, 60));
            return;
        }

        if (bindingUserService) {
            status.setText("… Shizuku wird verbunden");
            status.setTextColor(Color.rgb(120, 90, 0));
            return;
        }

        if (shizukuRunning()) {
            if (!shizukuPermissionGranted()) {
                status.setText("⚠ Shizuku aktiv – hier tippen und Berechtigung erlauben");
            } else if (!hasWritePermission()) {
                status.setText("⚠ Shizuku aktiv – WRITE_SECURE_SETTINGS wird vorbereitet");
            } else {
                status.setText("⚠ Shizuku aktiv – hier tippen zum Verbinden");
            }
        } else {
            status.setText("⚠ Shizuku nicht aktiv – „Nur WLAN“ kann nicht gelesen/geändert werden");
        }
        status.setTextColor(Color.rgb(190, 70, 0));
    }

    private void showPermissionHelp() {
        if (!shizukuRunning()) {
            new AlertDialog.Builder(this)
                    .setTitle("Shizuku starten")
                    .setMessage("Für Samsungs echten Modus „Nur WLAN“ braucht die App den privilegierten NetworkPolicy-Aufruf. Öffne Shizuku und starte den Dienst. aShell und manuelle service-call-Befehle sind danach nicht mehr nötig.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }

        try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                connectPrivilegedService(true);
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                Toast.makeText(this, "Bitte die Shizuku-Berechtigung für Mobile Daten Manager in Shizuku erlauben.", Toast.LENGTH_LONG).show();
            } else {
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE);
            }
        } catch (Throwable e) {
            Toast.makeText(this, "Shizuku ist noch nicht bereit.", Toast.LENGTH_LONG).show();
        }
    }

    private void connectPrivilegedService(boolean requestPermissionIfNeeded) {
        if (privilegedService != null || bindingUserService) return;
        if (!shizukuRunning()) {
            updatePermissionStatus();
            return;
        }
        if (!shizukuPermissionGranted()) {
            if (requestPermissionIfNeeded) {
                try { Shizuku.requestPermission(SHIZUKU_REQUEST_CODE); }
                catch (Throwable ignored) {}
            }
            updatePermissionStatus();
            return;
        }

        try {
            userServiceArgs = new Shizuku.UserServiceArgs(new ComponentName(this, PrivilegedService.class))
                    .daemon(false)
                    .processNameSuffix("network")
                    .tag("samsung-network-policy")
                    .version(4);
            bindingUserService = true;
            updatePermissionStatus();
            Shizuku.bindUserService(userServiceArgs, userServiceConnection);
        } catch (Throwable e) {
            bindingUserService = false;
            Toast.makeText(this, "Shizuku-Verbindung fehlgeschlagen: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            updatePermissionStatus();
        }
    }

    private void runGrantCommand() {
        if (privilegedService == null) return;
        final IPrivilegedService service = privilegedService;
        new Thread(() -> {
            int result = -1;
            try {
                String cmd = "pm grant " + getPackageName() + " " + WRITE_SECURE;
                result = service.runCommand(cmd);
            } catch (RemoteException ignored) {}

            final int exitCode = result;
            runOnUiThread(() -> {
                updatePermissionStatus();
                if (hasWritePermission()) {
                    Toast.makeText(this, "Berechtigung erteilt.", Toast.LENGTH_SHORT).show();
                    processPendingNetworkAction();
                    loadFirewallStatesAsync();
                } else {
                    Toast.makeText(this, "WRITE_SECURE_SETTINGS konnte nicht gesetzt werden (Code " + exitCode + ").", Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    private void registerSettingObserver() {
        Uri uri = Settings.Secure.getUriFor(KEY_MOBILE_PREFERRED);
        getContentResolver().registerContentObserver(uri, false, settingsObserver);
        observerRegistered = true;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private enum NetworkMode {
        AUTO("AUTO", "AUTO", "Mobile Daten oder WLAN"),
        WIFI_ONLY("WLAN", "WIFI", "Nur WLAN"),
        MOBILE_PREFERRED("MOBIL", "MOBILE", "Mobile Daten bevorzugt"),
        UNKNOWN("?", "UNKNOWN", "Status unbekannt");

        final String shortLabel;
        final String csvValue;
        final String longLabel;

        NetworkMode(String shortLabel, String csvValue, String longLabel) {
            this.shortLabel = shortLabel;
            this.csvValue = csvValue;
            this.longLabel = longLabel;
        }

        static NetworkMode fromCsv(String value) {
            if (value == null) return UNKNOWN;
            String v = value.trim().toUpperCase(Locale.ROOT);
            if ("AUTO".equals(v)) return AUTO;
            if ("WIFI".equals(v) || "WLAN".equals(v) || "WIFI_ONLY".equals(v)) return WIFI_ONLY;
            if ("MOBILE".equals(v) || "MOBIL".equals(v)) return MOBILE_PREFERRED;
            return UNKNOWN;
        }
    }

    private static class ProfileRecord {
        final NetworkMode mode;
        final boolean favorite;
        final boolean protectedFlag;

        ProfileRecord(NetworkMode mode, boolean favorite, boolean protectedFlag) {
            this.mode = mode;
            this.favorite = favorite;
            this.protectedFlag = protectedFlag;
        }
    }

    private static class AppEntry {
        final String label;
        final String packageName;
        final int uid;
        final boolean system;
        final Drawable icon;

        AppEntry(String label, String packageName, int uid, boolean system, Drawable icon) {
            this.label = label;
            this.packageName = packageName;
            this.uid = uid;
            this.system = system;
            this.icon = icon;
        }
    }

    private static class Row {
        final boolean header;
        final String headerText;
        final int headerCount;
        final AppEntry app;

        private Row(boolean header, String headerText, int headerCount, AppEntry app) {
            this.header = header;
            this.headerText = headerText;
            this.headerCount = headerCount;
            this.app = app;
        }

        static Row header(String text, int count) { return new Row(true, text, count, null); }
        static Row app(AppEntry app) { return new Row(false, null, 0, app); }
    }

    private class AppAdapter extends BaseAdapter {
        private final Context context;
        AppAdapter(Context c) { context = c; }
        @Override public int getCount() { return visibleRows.size(); }
        @Override public Object getItem(int position) { return visibleRows.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int position) { return visibleRows.get(position).header ? 0 : 1; }
        @Override public boolean isEnabled(int position) { return !visibleRows.get(position).header; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Row row = visibleRows.get(position);
            if (row.header) return headerView(row, convertView);
            return appView(row.app, convertView);
        }

        private View headerView(Row row, View convertView) {
            TextView tv;
            if (convertView instanceof TextView) tv = (TextView) convertView;
            else {
                tv = new TextView(context);
                tv.setTextSize(12);
                tv.setTypeface(null, 1);
                tv.setPadding(dp(8), dp(12), dp(8), dp(5));
                tv.setAlpha(0.72f);
            }
            tv.setText(row.headerText + "  (" + row.headerCount + ")");
            return tv;
        }

        private View appView(AppEntry app, View convertView) {
            AppHolder h;
            if (convertView == null || !(convertView.getTag() instanceof AppHolder)) {
                LinearLayout row = new LinearLayout(context);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(4), dp(6), dp(2), dp(6));

                ImageView icon = new ImageView(context);
                row.addView(icon, new LinearLayout.LayoutParams(dp(38), dp(38)));

                TextView star = new TextView(context);
                star.setGravity(Gravity.CENTER);
                star.setTextSize(23);
                row.addView(star, new LinearLayout.LayoutParams(dp(38), dp(50)));

                TextView protect = new TextView(context);
                protect.setGravity(Gravity.CENTER);
                protect.setTextSize(20);
                row.addView(protect, new LinearLayout.LayoutParams(dp(34), dp(50)));

                LinearLayout texts = new LinearLayout(context);
                texts.setOrientation(LinearLayout.VERTICAL);
                texts.setPadding(dp(3), 0, dp(4), 0);
                TextView name = new TextView(context);
                name.setTextSize(16);
                TextView pkg = new TextView(context);
                pkg.setTextSize(10);
                pkg.setAlpha(0.65f);
                texts.addView(name);
                texts.addView(pkg);
                row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                Button mode = new Button(context);
                mode.setAllCaps(false);
                mode.setTextSize(12);
                mode.setMinWidth(dp(78));
                row.addView(mode, new LinearLayout.LayoutParams(dp(84), dp(48)));

                h = new AppHolder(icon, star, protect, name, pkg, mode);
                row.setTag(h);
                convertView = row;
            } else {
                h = (AppHolder) convertView.getTag();
            }

            NetworkMode networkMode = modeForUid(app.uid);
            boolean favorite = favorites.contains(app.packageName);
            boolean protectedApp = isProtected(app);

            h.icon.setImageDrawable(app.icon);
            h.star.setText(favorite ? "★" : "☆");
            h.star.setContentDescription(favorite ? "Favorit entfernen" : "Als Favorit markieren");
            h.star.setOnClickListener(v -> toggleFavorite(app.packageName));

            h.protect.setText(protectedApp ? "⚠" : "◇");
            h.protect.setContentDescription(protectedApp ? "Schutz aktiv" : "Als wichtige App schützen");
            h.protect.setOnClickListener(v -> toggleProtected(app));

            h.name.setText(app.label);
            String suffix = app.system ? " · System" : "";
            if (protectedApp) suffix += isBuiltInCritical(app.packageName) ? " · Kernsystem" : " · geschützt";
            h.pkg.setText(app.packageName + suffix);

            h.mode.setText(networkMode.shortLabel);
            h.mode.setEnabled(true);
            h.mode.setOnClickListener(v -> showModeDialog(app));

            convertView.setOnClickListener(v -> showModeDialog(app));
            convertView.setOnLongClickListener(v -> {
                toggleProtected(app);
                return true;
            });
            return convertView;
        }
    }

    private static class AppHolder {
        final ImageView icon;
        final TextView star;
        final TextView protect;
        final TextView name;
        final TextView pkg;
        final Button mode;

        AppHolder(ImageView icon, TextView star, TextView protect, TextView name, TextView pkg, Button mode) {
            this.icon = icon;
            this.star = star;
            this.protect = protect;
            this.name = name;
            this.pkg = pkg;
            this.mode = mode;
        }
    }
}
