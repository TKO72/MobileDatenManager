# Mobile Daten Manager – V1

Eine kleine Android-App für Samsung/Android, die die systemeigene Einstellung
`mobile_data_preferred_uids` komfortabel verwaltet.

## Funktion

- Schalter pro App: **EIN = Mobile Daten bevorzugt**
- **AUS = Mobile Daten oder WLAN**
- WLAN bleibt verbunden, z. B. für ein lokales Intranet/AIDA-Bordnetz
- Suche nach App-Name und Paketname
- Gruppierung nach EIN/AUS
- Filter Alle / EIN / AUS
- Alle EIN / Alle AUS
- optional System-Apps anzeigen
- kein VPN, kein Root, keine Internetberechtigung
- Änderungen im Samsung-Menü werden beim Öffnen/Ändern automatisch neu eingelesen

## Warum ADB nötig ist

Die Android-Einstellung liegt in `Settings.Secure`. Schreiben ist normalen Apps nicht erlaubt.
Einmalig kann die Berechtigung per ADB vergeben werden:

```text
adb shell pm grant de.mobilepreferred.manager android.permission.WRITE_SECURE_SETTINGS
```

Danach ist für die tägliche Benutzung kein ADB mehr nötig.

## Bauen in Android Studio

1. Projektordner `MobileDatenManager` in Android Studio öffnen.
2. Gradle Sync abwarten.
3. `Build > Build App Bundle(s) / APK(s) > Build APK(s)`.
4. APK liegt anschließend unter `app/build/outputs/apk/debug/app-debug.apk`.
5. APK auf dem S25 installieren.
6. Einmal den oben genannten ADB-Befehl ausführen.
7. App starten. Oben muss `ADB-Berechtigung aktiv` stehen.

## AIDA-Beispiel

- AIDA-App: **AUS**
- Browser/WhatsApp/ChatGPT/TradingView: **EIN**

So kann das AIDA-WLAN für das Bord-Intranet verbunden bleiben, während ausgewählte Apps Mobilfunk bevorzugen.

## Technischer Hinweis

Die Android-Systemeinstellung arbeitet UID-basiert. Falls mehrere Pakete dieselbe UID teilen,
werden sie technisch gemeinsam umgestellt. Die App weist darauf hin.
