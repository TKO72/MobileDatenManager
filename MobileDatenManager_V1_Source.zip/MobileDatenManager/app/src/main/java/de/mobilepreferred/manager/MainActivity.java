package de.mobilepreferred.manager;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String KEY = "mobile_data_preferred_uids";
    private static final String WRITE_SECURE = "android.permission.WRITE_SECURE_SETTINGS";

    private final ArrayList<AppEntry> allApps = new ArrayList<>();
    private final ArrayList<Row> visibleRows = new ArrayList<>();
    private final Set<Integer> preferredUids = new HashSet<>();
    private final Map<Integer, List<AppEntry>> appsByUid = new HashMap<>();

    private EditText search;
    private Button filterAll;
    private Button filterOn;
    private Button filterOff;
    private TextView status;
    private TextView count;
    private CheckBox showSystem;
    private ListView list;
    private AppAdapter adapter;

    private int filter = 0; // 0 alle, 1 EIN, 2 AUS
    private boolean observerRegistered = false;

    private final ContentObserver settingsObserver = new ContentObserver(new Handler(Looper.getMainLooper())) {
        @Override public void onChange(boolean selfChange) {
            readPreferredUids();
            refreshRows();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        loadApps();
        readPreferredUids();
        refreshRows();
        registerSettingObserver();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionStatus();
        readPreferredUids();
        refreshRows();
    }

    @Override
    protected void onDestroy() {
        if (observerRegistered) {
            getContentResolver().unregisterContentObserver(settingsObserver);
        }
        super.onDestroy();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(14);
        root.setPadding(p, p, p, dp(8));

        TextView title = new TextView(this);
        title.setText("Mobile Daten Manager");
        title.setTextSize(24);
        title.setTypeface(null, 1);
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView hint = new TextView(this);
        hint.setText("EIN = Mobile Daten bevorzugt · AUS = Mobile Daten oder WLAN");
        hint.setTextSize(13);
        hint.setPadding(0, dp(4), 0, dp(8));
        root.addView(hint);

        status = new TextView(this);
        status.setTextSize(13);
        status.setPadding(dp(10), dp(8), dp(10), dp(8));
        status.setOnClickListener(v -> showPermissionHelp());
        root.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        search = new EditText(this);
        search.setHint("Apps suchen …");
        search.setSingleLine(true);
        search.setTextSize(17);
        root.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        LinearLayout filters = new LinearLayout(this);
        filters.setOrientation(LinearLayout.HORIZONTAL);
        filters.setPadding(0, dp(8), 0, dp(4));

        filterAll = makeButton("Alle");
        filterOn = makeButton("EIN");
        filterOff = makeButton("AUS");
        filters.addView(filterAll, weightParams());
        filters.addView(filterOn, weightParams());
        filters.addView(filterOff, weightParams());
        root.addView(filters);

        LinearLayout bulk = new LinearLayout(this);
        bulk.setOrientation(LinearLayout.HORIZONTAL);
        Button allOn = makeButton("Alle EIN");
        Button allOff = makeButton("Alle AUS");
        bulk.addView(allOn, weightParams());
        bulk.addView(allOff, weightParams());
        root.addView(bulk);

        LinearLayout options = new LinearLayout(this);
        options.setOrientation(LinearLayout.HORIZONTAL);
        options.setGravity(Gravity.CENTER_VERTICAL);
        showSystem = new CheckBox(this);
        showSystem.setText("System-Apps anzeigen");
        options.addView(showSystem, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        count = new TextView(this);
        count.setGravity(Gravity.END);
        options.addView(count, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(options);

        list = new ListView(this);
        list.setDividerHeight(1);
        adapter = new AppAdapter(this);
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { refreshRows(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        filterAll.setOnClickListener(v -> { filter = 0; refreshRows(); });
        filterOn.setOnClickListener(v -> { filter = 1; refreshRows(); });
        filterOff.setOnClickListener(v -> { filter = 2; refreshRows(); });
        showSystem.setOnCheckedChangeListener((buttonView, isChecked) -> refreshRows());
        allOn.setOnClickListener(v -> confirmBulk(true));
        allOff.setOnClickListener(v -> confirmBulk(false));

        updatePermissionStatus();
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setMinHeight(dp(46));
        return b;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> installed = pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(PackageManager.MATCH_ALL));
        Collator collator = Collator.getInstance(Locale.GERMAN);
        collator.setStrength(Collator.PRIMARY);

        allApps.clear();
        appsByUid.clear();

        for (ApplicationInfo ai : installed) {
            if (getPackageName().equals(ai.packageName)) continue;
            if (pm.checkPermission(Manifest.permission.INTERNET, ai.packageName) != PackageManager.PERMISSION_GRANTED) continue;

            String label;
            try { label = pm.getApplicationLabel(ai).toString(); }
            catch (Exception e) { label = ai.packageName; }

            boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0 || (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
            Drawable icon;
            try { icon = pm.getApplicationIcon(ai); }
            catch (Exception e) { icon = getApplicationInfo().loadIcon(pm); }

            AppEntry app = new AppEntry(label, ai.packageName, ai.uid, system, icon);
            allApps.add(app);
            appsByUid.computeIfAbsent(ai.uid, k -> new ArrayList<>()).add(app);
        }

        Collections.sort(allApps, (a, b) -> collator.compare(a.label, b.label));
    }

    private void readPreferredUids() {
        preferredUids.clear();
        String raw = Settings.Secure.getString(getContentResolver(), KEY);
        if (raw == null || raw.trim().isEmpty()) return;
        for (String s : raw.split(";")) {
            try { preferredUids.add(Integer.parseInt(s.trim())); }
            catch (NumberFormatException ignored) {}
        }
    }

    private boolean writePreferredUids(Set<Integer> newSet) {
        if (!hasWritePermission()) {
            showPermissionHelp();
            return false;
        }
        ArrayList<Integer> sorted = new ArrayList<>(newSet);
        Collections.sort(sorted);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sorted.size(); i++) {
            if (i > 0) sb.append(';');
            sb.append(sorted.get(i));
        }
        try {
            boolean ok = Settings.Secure.putString(getContentResolver(), KEY, sb.toString());
            if (!ok) {
                Toast.makeText(this, "Android hat die Änderung nicht übernommen.", Toast.LENGTH_LONG).show();
                return false;
            }
            readPreferredUids();
            refreshRows();
            return true;
        } catch (SecurityException e) {
            updatePermissionStatus();
            showPermissionHelp();
            return false;
        }
    }

    private void setUidPreferred(int uid, boolean enabled) {
        Set<Integer> next = new HashSet<>(preferredUids);
        if (enabled) next.add(uid); else next.remove(uid);
        if (writePreferredUids(next)) {
            List<AppEntry> shared = appsByUid.get(uid);
            if (shared != null && shared.size() > 1) {
                Toast.makeText(this, "Diese Apps teilen eine UID und wurden gemeinsam umgestellt.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void confirmBulk(boolean enable) {
        String action = enable ? "EIN" : "AUS";
        new AlertDialog.Builder(this)
                .setTitle("Alle Apps " + action + "?")
                .setMessage(enable
                        ? "Alle angezeigten Internet-Apps werden auf „Mobile Daten bevorzugt“ gesetzt. AIDA solltest du danach bei Bedarf wieder AUS schalten."
                        : "Alle angezeigten Internet-Apps werden auf „Mobile Daten oder WLAN“ zurückgesetzt.")
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton(action, (d, w) -> applyBulk(enable))
                .show();
    }

    private void applyBulk(boolean enable) {
        Set<Integer> next = new HashSet<>(preferredUids);
        for (AppEntry app : allApps) {
            if (!showSystem.isChecked() && app.system) continue;
            if (enable) next.add(app.uid); else next.remove(app.uid);
        }
        writePreferredUids(next);
    }

    private void refreshRows() {
        if (adapter == null) return;
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        boolean system = showSystem != null && showSystem.isChecked();

        ArrayList<AppEntry> on = new ArrayList<>();
        ArrayList<AppEntry> off = new ArrayList<>();

        for (AppEntry app : allApps) {
            if (!system && app.system) continue;
            boolean enabled = preferredUids.contains(app.uid);
            if (filter == 1 && !enabled) continue;
            if (filter == 2 && enabled) continue;
            if (!q.isEmpty()) {
                String hay = (app.label + " " + app.packageName).toLowerCase(Locale.ROOT);
                if (!hay.contains(q)) continue;
            }
            if (enabled) on.add(app); else off.add(app);
        }

        visibleRows.clear();
        if (filter != 2 && !on.isEmpty()) {
            visibleRows.add(Row.header("MOBILE DATEN BEVORZUGT", on.size()));
            for (AppEntry a : on) visibleRows.add(Row.app(a));
        }
        if (filter != 1 && !off.isEmpty()) {
            visibleRows.add(Row.header("STANDARD: MOBILE DATEN ODER WLAN", off.size()));
            for (AppEntry a : off) visibleRows.add(Row.app(a));
        }

        int totalVisible = on.size() + off.size();
        count.setText(on.size() + " EIN · " + off.size() + " AUS");
        filterAll.setText("Alle\n" + totalVisible);
        filterOn.setText("EIN\n" + on.size());
        filterOff.setText("AUS\n" + off.size());
        adapter.notifyDataSetChanged();
    }

    private boolean hasWritePermission() {
        return checkSelfPermission(WRITE_SECURE) == PackageManager.PERMISSION_GRANTED;
    }

    private void updatePermissionStatus() {
        if (status == null) return;
        if (hasWritePermission()) {
            status.setText("✓ ADB-Berechtigung aktiv – Schalter können direkt geändert werden");
            status.setTextColor(Color.rgb(0, 115, 60));
        } else {
            status.setText("⚠ ADB-Berechtigung fehlt – hier tippen für den Befehl");
            status.setTextColor(Color.rgb(190, 70, 0));
        }
    }

    private void showPermissionHelp() {
        String cmd = "adb shell pm grant " + getPackageName() + " android.permission.WRITE_SECURE_SETTINGS";
        new AlertDialog.Builder(this)
                .setTitle("Einmalige ADB-Berechtigung")
                .setMessage("1. Handy per ADB mit dem PC verbinden.\n\n2. Diesen Befehl ausführen:\n\n" + cmd + "\n\n3. Danach diese App erneut öffnen. Root ist nicht nötig.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void registerSettingObserver() {
        Uri uri = Settings.Secure.getUriFor(KEY);
        getContentResolver().registerContentObserver(uri, false, settingsObserver);
        observerRegistered = true;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static class AppEntry {
        final String label;
        final String packageName;
        final int uid;
        final boolean system;
        final Drawable icon;
        AppEntry(String label, String packageName, int uid, boolean system, Drawable icon) {
            this.label = label;
            this.packageName = packageName;
            this.uid = uid;
            this.system = system;
            this.icon = icon;
        }
    }

    private static class Row {
        final boolean header;
        final String headerText;
        final int headerCount;
        final AppEntry app;
        private Row(boolean header, String headerText, int headerCount, AppEntry app) {
            this.header = header; this.headerText = headerText; this.headerCount = headerCount; this.app = app;
        }
        static Row header(String text, int count) { return new Row(true, text, count, null); }
        static Row app(AppEntry app) { return new Row(false, null, 0, app); }
    }

    private class AppAdapter extends BaseAdapter {
        private final Context context;
        AppAdapter(Context c) { context = c; }
        @Override public int getCount() { return visibleRows.size(); }
        @Override public Object getItem(int position) { return visibleRows.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int position) { return visibleRows.get(position).header ? 0 : 1; }
        @Override public boolean isEnabled(int position) { return !visibleRows.get(position).header; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Row row = visibleRows.get(position);
            if (row.header) return headerView(row, convertView);
            return appView(row.app, convertView);
        }

        private View headerView(Row row, View convertView) {
            TextView tv;
            if (convertView instanceof TextView) tv = (TextView) convertView;
            else {
                tv = new TextView(context);
                tv.setTextSize(12);
                tv.setTypeface(null, 1);
                tv.setPadding(dp(10), dp(14), dp(8), dp(6));
                tv.setAlpha(0.72f);
            }
            tv.setText(row.headerText + "  (" + row.headerCount + ")");
            return tv;
        }

        private View appView(AppEntry app, View convertView) {
            AppHolder h;
            if (convertView == null || !(convertView.getTag() instanceof AppHolder)) {
                LinearLayout row = new LinearLayout(context);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(6), dp(7), dp(2), dp(7));

                ImageView icon = new ImageView(context);
                row.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));

                LinearLayout texts = new LinearLayout(context);
                texts.setOrientation(LinearLayout.VERTICAL);
                texts.setPadding(dp(10), 0, dp(8), 0);
                TextView name = new TextView(context);
                name.setTextSize(17);
                TextView pkg = new TextView(context);
                pkg.setTextSize(11);
                pkg.setAlpha(0.65f);
                texts.addView(name);
                texts.addView(pkg);
                row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                Switch sw = new Switch(context);
                sw.setShowText(true);
                sw.setTextOn("EIN");
                sw.setTextOff("AUS");
                sw.setMinWidth(dp(80));
                row.addView(sw, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(52)));

                h = new AppHolder(icon, name, pkg, sw);
                row.setTag(h);
                convertView = row;
            } else {
                h = (AppHolder) convertView.getTag();
            }

            h.icon.setImageDrawable(app.icon);
            h.name.setText(app.label);
            h.pkg.setText(app.packageName + (app.system ? " · System" : ""));
            h.sw.setOnCheckedChangeListener(null);
            h.sw.setChecked(preferredUids.contains(app.uid));
            h.sw.setEnabled(hasWritePermission());
            h.sw.setOnCheckedChangeListener((buttonView, isChecked) -> setUidPreferred(app.uid, isChecked));
            convertView.setOnClickListener(v -> {
                if (!hasWritePermission()) showPermissionHelp();
                else h.sw.setChecked(!h.sw.isChecked());
            });
            return convertView;
        }
    }

    private static class AppHolder {
        final ImageView icon;
        final TextView name;
        final TextView pkg;
        final Switch sw;
        AppHolder(ImageView icon, TextView name, TextView pkg, Switch sw) {
            this.icon = icon; this.name = name; this.pkg = pkg; this.sw = sw;
        }
    }
}
